import SpriteKit
import UIKit

final class Unit: SKNode {
    let team: Int
    var hp: CGFloat
    let maxHP: CGFloat
    var cooldown: CGFloat = CGFloat.random(in: 0...1)
    var strafeDir: CGFloat = Bool.random() ? 1 : -1
    var strafeTimer: CGFloat = 0
    let body: SKShapeNode
    let aim = SKNode()
    let gun: SKShapeNode
    let bar: SKShapeNode

    init(team: Int, hp: CGFloat, color: SKColor) {
        self.team = team
        self.hp = hp
        self.maxHP = hp
        body = SKShapeNode(circleOfRadius: 16)
        body.fillColor = color
        body.strokeColor = .white
        body.lineWidth = 2
        gun = SKShapeNode(rect: CGRect(x: 8, y: -3, width: 20, height: 6), cornerRadius: 2)
        gun.fillColor = .lightGray
        gun.strokeColor = .clear
        bar = SKShapeNode(rect: CGRect(x: 0, y: 0, width: 32, height: 4))
        bar.fillColor = .green
        bar.strokeColor = .clear
        bar.position = CGPoint(x: -16, y: 24)
        super.init()
        aim.addChild(gun)
        addChild(body)
        addChild(aim)
        addChild(bar)
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }

    func updateBar() {
        let r = max(hp / maxHP, 0.001)
        bar.xScale = r
        bar.fillColor = r < 0.35 ? .red : (r < 0.65 ? .yellow : .green)
    }
}

struct Bullet {
    let node: SKShapeNode
    let vel: CGVector
    let team: Int
    let dmg: CGFloat
    var life: CGFloat
}

final class GameScene: SKScene {
    var player: Unit!
    var units: [Unit] = []
    var bullets: [Bullet] = []
    var score = 0
    var wave = 0
    var gameOver = false
    var gameOverAt: TimeInterval = 0
    var lastTime: TimeInterval = 0

    let scoreLabel = SKLabelNode(fontNamed: "AvenirNext-Bold")
    let waveLabel = SKLabelNode(fontNamed: "AvenirNext-Bold")
    let hpLabel = SKLabelNode(fontNamed: "AvenirNext-Bold")
    let centerLabel = SKLabelNode(fontNamed: "AvenirNext-Bold")

    var moveTouch: UITouch?
    var aimTouch: UITouch?
    var moveOrigin = CGPoint.zero
    var aimOrigin = CGPoint.zero
    var moveVec = CGVector.zero
    var aimVec = CGVector.zero
    let moveBase = SKShapeNode(circleOfRadius: 50)
    let moveKnob = SKShapeNode(circleOfRadius: 22)
    let aimBase = SKShapeNode(circleOfRadius: 50)
    let aimKnob = SKShapeNode(circleOfRadius: 22)
    let haptic = UIImpactFeedbackGenerator(style: .light)

    override func didMove(to view: SKView) {
        backgroundColor = SKColor(red: 0.06, green: 0.07, blue: 0.12, alpha: 1)
        view.isMultipleTouchEnabled = true

        for l in [scoreLabel, waveLabel, hpLabel, centerLabel] {
            l.fontSize = 20
            l.fontColor = .white
            l.zPosition = 100
            addChild(l)
        }
        scoreLabel.horizontalAlignmentMode = .left
        hpLabel.horizontalAlignmentMode = .right
        centerLabel.fontSize = 30
        centerLabel.numberOfLines = 2
        centerLabel.verticalAlignmentMode = .center

        for (base, knob) in [(moveBase, moveKnob), (aimBase, aimKnob)] {
            base.strokeColor = SKColor(white: 1, alpha: 0.35)
            base.fillColor = SKColor(white: 1, alpha: 0.06)
            base.lineWidth = 3
            knob.fillColor = SKColor(white: 1, alpha: 0.35)
            knob.strokeColor = .clear
            base.zPosition = 90
            knob.zPosition = 91
            base.isHidden = true
            knob.isHidden = true
            addChild(base)
            addChild(knob)
        }
        layoutHUD()
        startGame()
    }

    override func didChangeSize(_ oldSize: CGSize) { layoutHUD() }

    func layoutHUD() {
        scoreLabel.position = CGPoint(x: 60, y: size.height - 34)
        waveLabel.position = CGPoint(x: size.width / 2, y: size.height - 34)
        hpLabel.position = CGPoint(x: size.width - 60, y: size.height - 34)
        centerLabel.position = CGPoint(x: size.width / 2, y: size.height / 2)
    }

    // MARK: - Game flow

    func startGame() {
        for u in units { u.removeFromParent() }
        for b in bullets { b.node.removeFromParent() }
        units = []
        bullets = []
        score = 0
        wave = 0
        gameOver = false
        centerLabel.isHidden = true

        player = Unit(team: 0, hp: 100, color: .systemBlue)
        player.position = CGPoint(x: size.width / 2, y: size.height / 2)
        addChild(player)
        units.append(player)
        nextWave()
    }

    func spawnAlly() {
        let a = Unit(team: 0, hp: 70, color: .systemGreen)
        a.position = CGPoint(x: player.position.x + CGFloat.random(in: -80...80),
                             y: player.position.y + CGFloat.random(in: -80...80))
        clamp(a)
        addChild(a)
        units.append(a)
    }

    func spawnEnemy() {
        let e = Unit(team: 1, hp: 40 + CGFloat(wave) * 6, color: .systemRed)
        let side = Int.random(in: 0...3)
        switch side {
        case 0: e.position = CGPoint(x: CGFloat.random(in: 0...size.width), y: size.height - 20)
        case 1: e.position = CGPoint(x: CGFloat.random(in: 0...size.width), y: 20)
        case 2: e.position = CGPoint(x: 20, y: CGFloat.random(in: 0...size.height))
        default: e.position = CGPoint(x: size.width - 20, y: CGFloat.random(in: 0...size.height))
        }
        addChild(e)
        units.append(e)
    }

    func nextWave() {
        wave += 1
        waveLabel.text = "Đợt \(wave)"
        player.hp = min(player.maxHP, player.hp + 30)
        let allies = units.filter { $0.team == 0 && $0 !== player }.count
        if allies < 2 { for _ in allies..<2 { spawnAlly() } }
        let count = min(3 + wave * 2, 18)
        for _ in 0..<count { spawnEnemy() }
    }

    func endGame() {
        gameOver = true
        gameOverAt = lastTime
        centerLabel.text = "GAME OVER - Điểm: \(score)\nChạm để chơi lại"
        centerLabel.isHidden = false
    }

    // MARK: - Helpers

    func clamp(_ u: SKNode) {
        u.position.x = min(max(u.position.x, 20), size.width - 20)
        u.position.y = min(max(u.position.y, 20), size.height - 20)
    }

    func fire(from u: Unit, angle: CGFloat, dmg: CGFloat) {
        let n = SKShapeNode(circleOfRadius: 3.5)
        n.fillColor = u.team == 0 ? .cyan : .orange
        n.strokeColor = .clear
        n.position = CGPoint(x: u.position.x + cos(angle) * 26, y: u.position.y + sin(angle) * 26)
        addChild(n)
        let speed: CGFloat = 520
        bullets.append(Bullet(node: n, vel: CGVector(dx: cos(angle) * speed, dy: sin(angle) * speed),
                              team: u.team, dmg: dmg, life: 1.4))
    }

    func nearestEnemy(of u: Unit) -> Unit? {
        var best: Unit?
        var bestD = CGFloat.greatestFiniteMagnitude
        for o in units where o.team != u.team {
            let dx = o.position.x - u.position.x
            let dy = o.position.y - u.position.y
            let d = dx * dx + dy * dy
            if d < bestD { bestD = d; best = o }
        }
        return best
    }

    func explode(at pos: CGPoint, color: SKColor) {
        for _ in 0..<8 {
            let p = SKShapeNode(circleOfRadius: 3)
            p.fillColor = color
            p.strokeColor = .clear
            p.position = pos
            addChild(p)
            let a = CGFloat.random(in: 0...(2 * CGFloat.pi))
            let r = CGFloat.random(in: 30...70)
            let move = SKAction.moveBy(x: cos(a) * r, y: sin(a) * r, duration: 0.4)
            let fade = SKAction.fadeOut(withDuration: 0.4)
            p.run(SKAction.sequence([SKAction.group([move, fade]), SKAction.removeFromParent()]))
        }
    }

    // MARK: - Update loop

    override func update(_ t: TimeInterval) {
        let dt: CGFloat = lastTime == 0 ? 1.0 / 60.0 : min(CGFloat(t - lastTime), 1.0 / 30.0)
        lastTime = t
        guard !gameOver else { return }
        updatePlayer(dt)
        updateAI(dt)
        updateBullets(dt)
        cleanup()
    }

    func updatePlayer(_ dt: CGFloat) {
        player.position.x += moveVec.dx * 210 * dt
        player.position.y += moveVec.dy * 210 * dt
        clamp(player)
        player.cooldown -= dt
        let mag = hypot(aimVec.dx, aimVec.dy)
        if aimTouch != nil && mag > 0.2 {
            let a = atan2(aimVec.dy, aimVec.dx)
            player.aim.zRotation = a
            if player.cooldown <= 0 {
                fire(from: player, angle: a, dmg: 20)
                player.cooldown = 0.16
            }
        }
    }

    func updateAI(_ dt: CGFloat) {
        for u in units where u !== player {
            u.cooldown -= dt
            guard let tgt = nearestEnemy(of: u) else { continue }
            let dx = tgt.position.x - u.position.x
            let dy = tgt.position.y - u.position.y
            let d = max(hypot(dx, dy), 0.001)
            let nx = dx / d
            let ny = dy / d

            u.strafeTimer -= dt
            if u.strafeTimer <= 0 {
                u.strafeDir = Bool.random() ? 1 : -1
                u.strafeTimer = CGFloat.random(in: 0.8...2.0)
            }
            let speed: CGFloat = u.team == 1 ? 70 + CGFloat(wave) * 3 : 100
            var mx: CGFloat = -ny * u.strafeDir * 0.6
            var my: CGFloat = nx * u.strafeDir * 0.6
            if d > 260 { mx += nx; my += ny } else if d < 150 { mx -= nx; my -= ny }
            u.position.x += mx * speed * dt
            u.position.y += my * speed * dt
            clamp(u)

            let ang = atan2(dy, dx)
            u.aim.zRotation = ang
            if u.cooldown <= 0 && d < 480 {
                let spread: CGFloat = u.team == 1 ? 0.22 : 0.1
                fire(from: u, angle: ang + CGFloat.random(in: -spread...spread), dmg: u.team == 1 ? 8 : 15)
                if u.team == 1 {
                    u.cooldown = max(0.6, CGFloat.random(in: 1.0...1.8) - CGFloat(wave) * 0.04)
                } else {
                    u.cooldown = 0.5
                }
            }
        }
    }

    func updateBullets(_ dt: CGFloat) {
        var i = bullets.count - 1
        while i >= 0 {
            var b = bullets[i]
            b.node.position.x += b.vel.dx * dt
            b.node.position.y += b.vel.dy * dt
            b.life -= dt
            let p = b.node.position
            var remove = b.life <= 0 || p.x < 0 || p.y < 0 || p.x > size.width || p.y > size.height
            if !remove {
                for u in units where u.team != b.team {
                    if hypot(u.position.x - p.x, u.position.y - p.y) < 19 {
                        u.hp -= b.dmg
                        u.body.run(SKAction.sequence([SKAction.fadeAlpha(to: 0.4, duration: 0.05),
                                                      SKAction.fadeAlpha(to: 1, duration: 0.05)]))
                        if u === player { haptic.impactOccurred() }
                        remove = true
                        break
                    }
                }
            }
            if remove {
                b.node.removeFromParent()
                bullets.remove(at: i)
            } else {
                bullets[i] = b
            }
            i -= 1
        }
    }

    func cleanup() {
        for u in units where u.hp <= 0 {
            if u.team == 1 { score += 10 }
            explode(at: u.position, color: u.team == 1 ? .systemRed : .systemBlue)
            u.removeFromParent()
        }
        let playerDead = player.hp <= 0
        units.removeAll { $0.hp <= 0 }
        for u in units { u.updateBar() }
        scoreLabel.text = "Điểm: \(score)"
        hpLabel.text = "HP: \(Int(max(0, player.hp)))"
        if playerDead { endGame(); return }
        if !units.contains(where: { $0.team == 1 }) { nextWave() }
    }

    // MARK: - Touch controls

    func show(_ base: SKShapeNode, _ knob: SKShapeNode, at p: CGPoint) {
        base.position = p
        knob.position = p
        base.isHidden = false
        knob.isHidden = false
    }

    func stick(from o: CGPoint, to p: CGPoint, knob: SKShapeNode) -> CGVector {
        var dx = p.x - o.x
        var dy = p.y - o.y
        let d = hypot(dx, dy)
        let maxR: CGFloat = 50
        if d > maxR { dx = dx / d * maxR; dy = dy / d * maxR }
        knob.position = CGPoint(x: o.x + dx, y: o.y + dy)
        return CGVector(dx: dx / maxR, dy: dy / maxR)
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if gameOver {
            if lastTime - gameOverAt > 1 { startGame() }
            return
        }
        for t in touches {
            let p = t.location(in: self)
            if p.x < size.width / 2 {
                if moveTouch == nil {
                    moveTouch = t
                    moveOrigin = p
                    show(moveBase, moveKnob, at: p)
                }
            } else if aimTouch == nil {
                aimTouch = t
                aimOrigin = p
                show(aimBase, aimKnob, at: p)
            }
        }
    }

    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches {
            let p = t.location(in: self)
            if t === moveTouch {
                moveVec = stick(from: moveOrigin, to: p, knob: moveKnob)
            } else if t === aimTouch {
                aimVec = stick(from: aimOrigin, to: p, knob: aimKnob)
            }
        }
    }

    func release(_ touches: Set<UITouch>) {
        for t in touches {
            if t === moveTouch {
                moveTouch = nil
                moveVec = .zero
                moveBase.isHidden = true
                moveKnob.isHidden = true
            } else if t === aimTouch {
                aimTouch = nil
                aimVec = .zero
                aimBase.isHidden = true
                aimKnob.isHidden = true
            }
        }
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) { release(touches) }
    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) { release(touches) }
}
