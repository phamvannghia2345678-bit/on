import SwiftUI
import SpriteKit

@main
struct ShooterApp: App {
    static let scene: GameScene = {
        let s = GameScene(size: CGSize(width: 844, height: 390))
        s.scaleMode = .resizeFill
        return s
    }()

    var body: some Scene {
        WindowGroup {
            SpriteView(scene: ShooterApp.scene, options: [.ignoresSiblingOrder])
                .ignoresSafeArea()
                .statusBarHidden(true)
                .persistentSystemOverlays(.hidden)
        }
    }
}
