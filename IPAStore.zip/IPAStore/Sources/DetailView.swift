import SwiftUI

struct DetailView: View {
    let app: AppItem
    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                ZStack {
                    app.gradient.frame(height: 220)
                    IconView(app: app, size: 110)
                }
                .clipShape(RoundedRectangle(cornerRadius: 32, style: .continuous))
                .padding(.horizontal)
                VStack(spacing: 6) {
                    Text(app.name).font(.largeTitle.bold())
                    Text(app.subtitle).foregroundStyle(.secondary)
                }
                GetButton(app: app).scaleEffect(1.3).padding(.vertical, 6)
                HStack {
                    info("Phiên bản", app.version)
                    Divider().frame(height: 30)
                    info("Dung lượng", app.size)
                    Divider().frame(height: 30)
                    info("Thể loại", app.category)
                }
                .padding().background(.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 20))
                .padding(.horizontal)
                Text(app.desc).padding(.horizontal).frame(maxWidth: .infinity, alignment: .leading)
            }.padding(.vertical)
        }
        .background(Color(hex: "#0F0E17").ignoresSafeArea())
        .navigationBarTitleDisplayMode(.inline)
    }
    func info(_ t: String, _ v: String) -> some View {
        VStack(spacing: 4) { Text(t).font(.caption).foregroundStyle(.secondary); Text(v).font(.subheadline.bold()) }
            .frame(maxWidth: .infinity)
    }
}

struct LibraryView: View {
    @EnvironmentObject var store: StoreViewModel
    @EnvironmentObject var dl: DownloadManager
    var body: some View {
        let items = store.apps.filter { dl.files[$0.id] != nil || dl.progress[$0.id] != nil }
        List(items) { AppRow(app: $0).listRowBackground(Color.clear).listRowSeparator(.hidden) }
            .listStyle(.plain)
            .overlay { if items.isEmpty { Text("Chưa tải app nào").foregroundStyle(.secondary) } }
            .navigationTitle("Đã tải")
    }
}
