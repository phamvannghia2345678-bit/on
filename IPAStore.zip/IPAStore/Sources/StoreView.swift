import SwiftUI

struct StoreView: View {
    @EnvironmentObject var store: StoreViewModel

    var body: some View {
        ZStack {
            LinearGradient(colors: [Color(hex: "#0F0E17"), Color(hex: "#1A1033")], startPoint: .top, endPoint: .bottom)
                .ignoresSafeArea()
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 24) {
                    if !store.featured.isEmpty {
                        Text("Nổi bật").font(.title2.bold()).padding(.horizontal)
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: 16) {
                                ForEach(store.featured) { app in
                                    NavigationLink(value: app) { FeaturedCard(app: app) }.buttonStyle(.plain)
                                }
                            }.padding(.horizontal)
                        }
                    }
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack {
                            ForEach(store.categories, id: \.self) { c in
                                Text(c).font(.subheadline.weight(.semibold))
                                    .padding(.horizontal, 16).padding(.vertical, 8)
                                    .background(store.category == c ? Color(hex: "#7F5AF0") : Color.white.opacity(0.08), in: Capsule())
                                    .onTapGesture { withAnimation(.spring) { store.category = c } }
                            }
                        }.padding(.horizontal)
                    }
                    VStack(spacing: 4) {
                        ForEach(store.filtered) { app in
                            NavigationLink(value: app) { AppRow(app: app) }.buttonStyle(.plain)
                        }
                    }.padding(.horizontal)
                }.padding(.vertical)
            }
        }
        .navigationTitle("IPA Store")
        .searchable(text: $store.query, prompt: "Tìm app")
        .navigationDestination(for: AppItem.self) { DetailView(app: $0) }
    }
}

struct IconView: View {
    let app: AppItem; var size: CGFloat = 64
    var body: some View {
        AsyncImage(url: URL(string: app.icon)) { img in img.resizable().scaledToFill() }
            placeholder: { app.gradient }
            .frame(width: size, height: size)
            .clipShape(RoundedRectangle(cornerRadius: size * 0.225, style: .continuous))
            .shadow(color: Color(hex: app.c1).opacity(0.5), radius: 10, y: 5)
    }
}

struct FeaturedCard: View {
    let app: AppItem
    var body: some View {
        ZStack(alignment: .bottomLeading) {
            app.gradient
            Circle().fill(.white.opacity(0.15)).frame(width: 180).offset(x: 140, y: -60)
            VStack(alignment: .leading, spacing: 6) {
                Spacer()
                IconView(app: app, size: 56)
                Text(app.name).font(.title2.bold())
                Text(app.subtitle).font(.subheadline).opacity(0.9)
            }.padding(20).foregroundStyle(.white)
        }
        .frame(width: 300, height: 190)
        .clipShape(RoundedRectangle(cornerRadius: 28, style: .continuous))
        .shadow(color: Color(hex: app.c1).opacity(0.4), radius: 16, y: 10)
    }
}

struct AppRow: View {
    let app: AppItem
    var body: some View {
        HStack(spacing: 14) {
            IconView(app: app)
            VStack(alignment: .leading, spacing: 3) {
                Text(app.name).font(.headline)
                Text(app.subtitle).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                Text("\(app.category) • \(app.size)").font(.caption2).foregroundStyle(.tertiary)
            }
            Spacer()
            GetButton(app: app)
        }
        .padding(12)
        .background(.white.opacity(0.05), in: RoundedRectangle(cornerRadius: 20, style: .continuous))
        .padding(.vertical, 4)
    }
}

struct GetButton: View {
    let app: AppItem
    @EnvironmentObject var dl: DownloadManager
    var body: some View {
        Group {
            if let p = dl.progress[app.id] {
                ZStack {
                    Circle().stroke(.white.opacity(0.15), lineWidth: 3)
                    Circle().trim(from: 0, to: p).stroke(Color(hex: "#2CB67D"), style: StrokeStyle(lineWidth: 3, lineCap: .round)).rotationEffect(.degrees(-90))
                    Image(systemName: "stop.fill").font(.system(size: 9))
                }.frame(width: 30, height: 30)
            } else if let f = dl.files[app.id] {
                if app.manifestURL != nil {
                    pill("CÀI") { dl.install(app) }
                } else {
                    ShareLink(item: f) { label("MỞ") }
                }
            } else {
                pill("TẢI") { dl.start(app) }
            }
        }
    }
    func label(_ t: String) -> some View {
        Text(t).font(.subheadline.bold()).foregroundStyle(.white)
            .padding(.horizontal, 20).padding(.vertical, 7)
            .background(Color(hex: "#7F5AF0"), in: Capsule())
    }
    func pill(_ t: String, _ action: @escaping () -> Void) -> some View {
        Button(action: action) { label(t) }
    }
}
