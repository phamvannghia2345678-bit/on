import SwiftUI

@main
struct IPAStoreApp: App {
    @StateObject private var store = StoreViewModel()
    @StateObject private var dl = DownloadManager()
    var body: some Scene {
        WindowGroup {
            TabView {
                NavigationStack { StoreView() }
                    .tabItem { Label("Khám phá", systemImage: "sparkles") }
                NavigationStack { LibraryView() }
                    .tabItem { Label("Đã tải", systemImage: "arrow.down.circle.fill") }
            }
            .tint(Color(hex: "#7F5AF0"))
            .preferredColorScheme(.dark)
            .environmentObject(store)
            .environmentObject(dl)
            .task { await store.load() }
        }
    }
}
