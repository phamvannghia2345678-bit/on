import SwiftUI

struct AppItem: Identifiable, Codable, Hashable {
    let id, name, subtitle, category, version, size, icon, ipaURL: String
    let manifestURL: String?
    let desc, c1, c2: String
    let featured: Bool
    var gradient: LinearGradient {
        LinearGradient(colors: [Color(hex: c1), Color(hex: c2)], startPoint: .topLeading, endPoint: .bottomTrailing)
    }
}

extension Color {
    init(hex: String) {
        let s = hex.replacingOccurrences(of: "#", with: "")
        var v: UInt64 = 0; Scanner(string: s).scanHexInt64(&v)
        self.init(red: Double((v >> 16) & 255) / 255, green: Double((v >> 8) & 255) / 255, blue: Double(v & 255) / 255)
    }
}

@MainActor
final class StoreViewModel: ObservableObject {
    @Published var apps: [AppItem] = []
    @Published var query = ""
    @Published var category = "Tất cả"
    // Đặt link JSON của bạn ở đây để cập nhật danh sách từ xa
    let remoteURL: URL? = nil

    var categories: [String] { ["Tất cả"] + Array(Set(apps.map(\.category))).sorted() }
    var featured: [AppItem] { apps.filter(\.featured) }
    var filtered: [AppItem] {
        apps.filter { (category == "Tất cả" || $0.category == category) &&
            (query.isEmpty || $0.name.localizedCaseInsensitiveContains(query)) }
    }

    func load() async {
        if let u = remoteURL, let (d, _) = try? await URLSession.shared.data(from: u),
           let list = try? JSONDecoder().decode([AppItem].self, from: d) { apps = list; return }
        if let u = Bundle.main.url(forResource: "apps", withExtension: "json"),
           let d = try? Data(contentsOf: u), let list = try? JSONDecoder().decode([AppItem].self, from: d) { apps = list }
    }
}
