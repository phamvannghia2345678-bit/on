import SwiftUI

final class DownloadManager: NSObject, ObservableObject, URLSessionDownloadDelegate {
    @Published var progress: [String: Double] = [:]
    @Published var files: [String: URL] = [:]
    private var tasks: [Int: String] = [:]
    private lazy var session = URLSession(configuration: .default, delegate: self, delegateQueue: .main)

    func start(_ app: AppItem) {
        guard let url = URL(string: app.ipaURL) else { return }
        let t = session.downloadTask(with: url)
        tasks[t.taskIdentifier] = app.id
        progress[app.id] = 0
        t.resume()
    }

    func install(_ app: AppItem) {
        guard let m = app.manifestURL,
              let u = URL(string: "itms-services://?action=download-manifest&url=\(m)") else { return }
        UIApplication.shared.open(u)
    }

    func urlSession(_ s: URLSession, downloadTask t: URLSessionDownloadTask, didWriteData _: Int64,
                    totalBytesWritten w: Int64, totalBytesExpectedToWrite e: Int64) {
        guard let id = tasks[t.taskIdentifier], e > 0 else { return }
        progress[id] = Double(w) / Double(e)
    }

    func urlSession(_ s: URLSession, downloadTask t: URLSessionDownloadTask, didFinishDownloadingTo loc: URL) {
        guard let id = tasks[t.taskIdentifier] else { return }
        let dest = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent("\(id).ipa")
        try? FileManager.default.removeItem(at: dest)
        try? FileManager.default.moveItem(at: loc, to: dest)
        files[id] = dest
        progress[id] = nil
        tasks[t.taskIdentifier] = nil
    }

    func urlSession(_ s: URLSession, task t: URLSessionTask, didCompleteWithError e: Error?) {
        if e != nil, let id = tasks[t.taskIdentifier] { progress[id] = nil; tasks[t.taskIdentifier] = nil }
    }
}
